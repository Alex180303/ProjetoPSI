<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var common\models\Adocao $model */

$this->title = 'Update Adocao: ' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Adocaos', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="adocao-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
